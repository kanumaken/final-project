from flask import Flask, render_template, request, redirect, flash
from pymongo import MongoClient
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Needed for flash messages

# MongoDB setup
client = MongoClient("mongodb://localhost:27017/")
db = client['income_survey']
collection = db['participants']

@app.route('/', methods=['GET', 'POST'])
def survey():
    if request.method == 'POST':
        age = request.form.get('age')
        gender = request.form.get('gender')
        income = request.form.get('income')

        # Expense categories
        expenses = {}
        categories = ['utilities', 'entertainment', 'school_fees', 'shopping', 'healthcare']
